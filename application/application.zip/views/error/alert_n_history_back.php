<script>
alert('<?=$message;?>');
window.history.back();
</script>