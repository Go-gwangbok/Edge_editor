	<!-- Footer -->
    <hr>    
    <div id="footer">
      <div class="container">
            <p>©AKAON MUSE 2013</p>
      </div>
    </div>    
	<!-- Footer End-->             	
  </body>
</html>
